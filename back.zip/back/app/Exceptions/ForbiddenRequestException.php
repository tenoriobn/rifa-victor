<?php

namespace App\Exceptions;

use Exception;

class ForbiddenRequestException extends Exception
{
    //
}
